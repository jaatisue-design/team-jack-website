const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),urlmod=require('url');
const PORT=Number(process.env.PORT||3000),ROOT=__dirname,PUBLIC=path.join(ROOT,'public'),DATA=path.join(ROOT,'data'),DB=path.join(DATA,'db.json'),BACKUPS=path.join(DATA,'backups');
const SECRET=process.env.SESSION_SECRET||'CHANGE_ME_TEAM_JACK_SECRET';
const ADMIN_EMAIL=(process.env.ADMIN_EMAIL||'admin@teamjack.local').toLowerCase();
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'ChangeThisAdminPassword123!';
const EMAIL_TO=(process.env.EMAIL_TO||'jaatisue@gmail.com').trim();
const SMTP_HOST=process.env.SMTP_HOST||'smtp.gmail.com';
const SMTP_PORT=Number(process.env.SMTP_PORT||465);
const SMTP_USER=(process.env.SMTP_USER||'').trim();
const SMTP_PASS=process.env.SMTP_PASS||'';
let mailer=null;
async function sendEmail(subject,text,html){
  if(!SMTP_USER||!SMTP_PASS) return {sent:false,reason:'SMTP is not configured'};
  try{
    if(!mailer){const nodemailer=require('nodemailer');mailer=nodemailer.createTransport({host:SMTP_HOST,port:SMTP_PORT,secure:SMTP_PORT===465,auth:{user:SMTP_USER,pass:SMTP_PASS}})}
    await mailer.sendMail({from:SMTP_USER,to:EMAIL_TO,subject,text,html});
    return {sent:true};
  }catch(e){console.error('Email error:',e.message);return {sent:false,reason:e.message}}
}
fs.mkdirSync(DATA,{recursive:true});fs.mkdirSync(BACKUPS,{recursive:true});
const empty={users:[],updates:[],messages:[],sessions:[],notifications:[],settings:{videoUrl:'',bannerData:'',siteName:'Team Jack',whatsapp:'917357839694',instagram:'vikashchoudhary.666'},analytics:{visits:0,unique:[],events:[]}};
function load(){try{return {...empty,...JSON.parse(fs.readFileSync(DB,'utf8'))}}catch{return structuredClone(empty)}}
let db=load();function backup(){try{fs.writeFileSync(path.join(BACKUPS,`db-${new Date().toISOString().replace(/[:.]/g,'-')}.json`),JSON.stringify(db,null,2));const f=fs.readdirSync(BACKUPS).sort();while(f.length>20)fs.unlinkSync(path.join(BACKUPS,f.shift()))}catch{}}
function save(){backup();fs.writeFileSync(DB,JSON.stringify(db,null,2))}
function id(){return crypto.randomBytes(12).toString('hex')}
function hash(p,s=crypto.randomBytes(16).toString('hex')){return `${s}:${crypto.scryptSync(p,s,64).toString('hex')}`}
function check(p,stored){try{const [s,h]=stored.split(':');return crypto.timingSafeEqual(crypto.scryptSync(p,s,64),Buffer.from(h,'hex'))}catch{return false}}
function cookies(req){const o={};for(const x of (req.headers.cookie||'').split(';')){const i=x.indexOf('=');if(i>0)o[x.slice(0,i).trim()]=decodeURIComponent(x.slice(i+1))}return o}
function current(req){const sid=cookies(req).tj_session;if(!sid)return null;const s=db.sessions.find(x=>x.id===sid&&x.expires>Date.now());if(!s)return null;return db.users.find(x=>x.id===s.userId)||null}
function safe(u){return u&&{id:u.id,name:u.name,email:u.email,phone:u.phone||'',admin:!!u.admin,createdAt:u.createdAt}}
function send(res,status,data,type='application/json'){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN','Referrer-Policy':'strict-origin-when-cross-origin'});res.end(type==='application/json'?JSON.stringify(data):data)}
function cookie(res,v,maxAge=604800){res.setHeader('Set-Cookie',`tj_session=${encodeURIComponent(v)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}`)}
async function body(req){let s='';for await(const c of req){s+=c;if(s.length>3e6)throw Error('Body too large')}return s?JSON.parse(s):{}}
function auth(req,res,admin=false){const u=current(req);if(!u){send(res,401,{error:'Login required'});return null}if(admin&&!u.admin){send(res,403,{error:'Admin access required'});return null}return u}
const limits=new Map();function limited(req,key,max=60){const k=key+':' +(req.socket.remoteAddress||'x'),now=Date.now(),a=(limits.get(k)||[]).filter(t=>t>now-60000);a.push(now);limits.set(k,a);return a.length>max}
function track(req,type){const ip=req.socket.remoteAddress||'unknown',today=new Date().toISOString().slice(0,10);db.analytics.visits=(db.analytics.visits||0)+1;if(!db.analytics.unique.includes(ip+'|'+today))db.analytics.unique.push(ip+'|'+today);db.analytics.events=(db.analytics.events||[]).concat({type,at:new Date().toISOString()}).slice(-5000)}
async function api(req,res){
 if(limited(req,req.url.split('?')[0],req.url.includes('/login')||req.url.includes('/signup')?12:120)){return send(res,429,{error:'Too many requests. Please try again shortly.'})}
 const u=current(req),uurl=new URL(req.url,`http://${req.headers.host}`),p=uurl.pathname;
 if(req.method==='GET'&&p==='/api/me')return send(res,200,{user:safe(u)});
 if(req.method==='GET'&&p==='/api/settings')return send(res,200,{settings:{...db.settings,bannerData:db.settings.bannerData||''}});
 if(req.method==='GET'&&p==='/api/updates')return send(res,200,{updates:db.updates.filter(x=>x.published).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))});
 if(req.method==='GET'&&p==='/api/notifications'){if(!u)return send(res,200,{notifications:[]});return send(res,200,{notifications:db.notifications.filter(n=>n.userId===u.id||n.userId===null).slice(-50).reverse()})}
 try{const b=await body(req);
  if(req.method==='POST'&&p==='/api/visit'){track(req,'visit');return send(res,200,{ok:true})}
  if(req.method==='POST'&&p==='/api/signup'){const name=String(b.name||'').trim(),email=String(b.email||'').trim().toLowerCase(),password=String(b.password||'');if(name.length<2||name.length>60||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<8)return send(res,400,{error:'Enter a valid name, email and password (8+ characters).'});if(db.users.some(x=>x.email===email))return send(res,409,{error:'An account with this email already exists.'});const usr={id:id(),name,email,passwordHash:hash(password),admin:false,createdAt:new Date().toISOString()};db.users.push(usr);db.notifications.push({id:id(),userId:usr.id,title:'Welcome to Team Jack',body:'Your account has been created successfully.',createdAt:new Date().toISOString(),read:false});const sid=id();db.sessions.push({id:sid,userId:usr.id,expires:Date.now()+604800000});save();cookie(res,sid);track(req,'signup');sendEmail('New Team Jack signup',`New user signup\n\nName: ${name}\nEmail: ${email}\nTime: ${new Date().toISOString()}`,`<h2>New Team Jack signup</h2><p><b>Name:</b> ${name}</p><p><b>Email:</b> ${email}</p><p><b>Time:</b> ${new Date().toISOString()}</p>`).catch(()=>{});return send(res,201,{user:safe(usr)})}
  if(req.method==='POST'&&p==='/api/login'){const email=String(b.email||'').trim().toLowerCase(),password=String(b.password||'');let usr=db.users.find(x=>x.email===email);if(!usr&&email===ADMIN_EMAIL&&password===ADMIN_PASSWORD){usr={id:'admin',name:'Team Jack Admin',email:ADMIN_EMAIL,passwordHash:hash(ADMIN_PASSWORD),admin:true,createdAt:new Date().toISOString()};db.users.push(usr);save()}if(!usr||!check(password,usr.passwordHash))return send(res,401,{error:'Invalid email or password.'});const sid=id();db.sessions.push({id:sid,userId:usr.id,expires:Date.now()+604800000});save();cookie(res,sid);track(req,'login');return send(res,200,{user:safe(usr)})}
  if(req.method==='POST'&&p==='/api/logout'){const sid=cookies(req).tj_session;db.sessions=db.sessions.filter(x=>x.id!==sid);save();cookie(res,'',0);return send(res,200,{ok:true})}
  if(req.method==='PATCH'&&p==='/api/profile'){const me=auth(req,res);if(!me)return;const name=String(b.name||'').trim(),phone=String(b.phone||'').trim();if(name.length<2)return send(res,400,{error:'Name is required.'});me.name=name;me.phone=phone;save();return send(res,200,{user:safe(me)})}
  if(req.method==='POST'&&p==='/api/contact'){const name=String(b.name||'').trim(),email=String(b.email||'').trim(),message=String(b.message||'').trim();if(name.length<2||message.length<3)return send(res,400,{error:'Please enter your name and message.'});db.messages.push({id:id(),name,email,message,createdAt:new Date().toISOString(),read:false,userId:u?.id||null});save();track(req,'message');sendEmail('New Team Jack inquiry',`New message from ${name} (${email||'no email'})\n\n${message}\n\nTime: ${new Date().toISOString()}`,`<h2>New Team Jack inquiry</h2><p><b>Name:</b> ${name}</p><p><b>Email:</b> ${email||'Not provided'}</p><p><b>Message:</b></p><p>${message.replace(/\n/g,'<br>')}</p>`).catch(()=>{});return send(res,201,{ok:true,message:'Message received.'})}
  if(req.method==='POST'&&p==='/api/subscribe'){const email=String(b.email||'').trim().toLowerCase();if(!/^\S+@\S+\.\S+$/.test(email))return send(res,400,{error:'Enter a valid email.'});db.messages.push({id:id(),name:'Newsletter',email,message:'Newsletter subscription',createdAt:new Date().toISOString(),read:false,userId:u?.id||null});save();return send(res,201,{ok:true})}
  if(req.method==='POST'&&p==='/api/admin/email-test'){if(!auth(req,res,true))return;const r=await sendEmail('Team Jack email test','This is a test email from your Team Jack website.', '<h2>Team Jack email test</h2><p>Your email notifications are configured correctly.</p>');if(!r.sent)return send(res,503,{error:'Email is not configured or sending failed.',detail:r.reason});return send(res,200,{ok:true,message:`Test email sent to ${EMAIL_TO}`})}
  if(req.method==='GET'&&p==='/api/admin/email-status'){if(!auth(req,res,true))return;return send(res,200,{configured:!!(SMTP_USER&&SMTP_PASS),recipient:EMAIL_TO,sender:SMTP_USER||null})}
  if(req.method==='GET'&&p==='/api/admin/stats'){if(!auth(req,res,true))return;const last7=db.analytics.events.filter(e=>e.at>Date.now()-7*864e5);return send(res,200,{stats:{users:db.users.length,messages:db.messages.length,updates:db.updates.length,visits:db.analytics.visits||0,last7:last7.length,uniqueDays:db.analytics.unique.length}})}
  if(req.method==='GET'&&p==='/api/admin/users'){if(!auth(req,res,true))return;return send(res,200,{users:db.users.map(safe)})}
  if(req.method==='GET'&&p==='/api/admin/messages'){if(!auth(req,res,true))return;return send(res,200,{messages:db.messages.slice().reverse()})}
  if(req.method==='PATCH'&&p.startsWith('/api/admin/messages/')){if(!auth(req,res,true))return;const m=db.messages.find(x=>x.id===p.split('/').pop());if(!m)return send(res,404,{error:'Message not found'});m.read=!!b.read;save();return send(res,200,{ok:true})}
  if(req.method==='GET'&&p==='/api/admin/updates'){if(!auth(req,res,true))return;return send(res,200,{updates:db.updates})}
  if(req.method==='POST'&&p==='/api/admin/updates'){if(!auth(req,res,true))return;const title=String(b.title||'').trim(),text=String(b.body||'').trim();if(!title||!text)return send(res,400,{error:'Title and update text are required.'});const item={id:id(),title,body:text,icon:String(b.icon||'📢').slice(0,4),createdAt:new Date().toISOString(),published:b.published!==false};db.updates.push(item);db.notifications.push({id:id(),userId:null,title,body:text,createdAt:new Date().toISOString(),read:false});save();return send(res,201,{update:item})}
  if(req.method==='DELETE'&&p.startsWith('/api/admin/updates/')){if(!auth(req,res,true))return;const i=p.split('/').pop();db.updates=db.updates.filter(x=>x.id!==i);save();return send(res,200,{ok:true})}
  if(req.method==='GET'&&p==='/api/admin/settings'){if(!auth(req,res,true))return;return send(res,200,{settings:db.settings})}
  if(req.method==='PUT'&&p==='/api/admin/settings'){if(!auth(req,res,true))return;const allowed=['videoUrl','siteName','whatsapp','instagram'];for(const k of allowed)if(b[k]!==undefined)db.settings[k]=String(b[k]).trim();if(b.bannerData!==undefined){if(String(b.bannerData).length>1.5e6)return send(res,400,{error:'Banner image is too large.'});db.settings.bannerData=String(b.bannerData)}save();return send(res,200,{settings:db.settings})}
  if(req.method==='POST'&&p==='/api/admin/notify'){if(!auth(req,res,true))return;const title=String(b.title||'').trim(),bodyText=String(b.body||'').trim(),userId=b.userId?String(b.userId):null;if(!title||!bodyText)return send(res,400,{error:'Title and message required.'});db.notifications.push({id:id(),userId,title,body:bodyText,createdAt:new Date().toISOString(),read:false});save();return send(res,201,{ok:true})}
  if(req.method==='GET'&&p==='/api/admin/backup'){if(!auth(req,res,true))return;res.writeHead(200,{'Content-Type':'application/json','Content-Disposition':'attachment; filename="team-jack-backup.json"'});return res.end(JSON.stringify(db,null,2))}
 }catch(e){return send(res,400,{error:e.message||'Bad request'})}
 return send(res,404,{error:'Not found'});
}
const mime={'.html':'text/html; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{if(req.url.startsWith('/api/'))return api(req,res);let pathname=new URL(req.url,`http://${req.headers.host}`).pathname;if(pathname==='/')pathname='/index.html';const file=path.normalize(path.join(PUBLIC,pathname));if(!file.startsWith(PUBLIC))return send(res,403,{error:'Forbidden'});fs.readFile(file,(e,d)=>{if(e)return send(res,404,'Not found','text/plain');res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(d)})});
server.listen(PORT,()=>console.log(`Team Jack running on http://localhost:${PORT}`));
