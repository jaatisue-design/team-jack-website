# Team Jack Full Website

## Included
- User signup/login/logout
- Profile + notifications
- User dashboard/account
- Contact/support messages
- WhatsApp + Instagram links with pre-filled WhatsApp inquiry
- Share button
- Dark/light mode
- Admin dashboard
- User/message/update management
- Banner/video/site settings
- Admin notifications
- Visitor/event statistics
- Search
- PWA / Add to Home Screen
- Loading-free lightweight UI with smooth interactions
- Rate limiting and security headers
- Automatic rolling JSON database backups (20 copies)
- Manual database backup download from Admin Dashboard
- Email alerts to `jaatisue@gmail.com` for new signups and contact inquiries
- Admin email test endpoint for checking SMTP configuration

## Data flow
All website data is stored in `data/db.json` on your server. The admin dashboard reads it through protected admin APIs. Automatic backups are written to `data/backups/`.

## Run
1. Install Node.js 18+.
2. Copy `.env.example` to `.env` and set a strong admin email/password and session secret.
3. Run `npm start`.
4. Open `http://localhost:3000`.

### Email setup
The site can email `jaatisue@gmail.com` when a new user signs up or someone sends a contact/inquiry message. For Gmail, enable 2-Step Verification on the sending Google account, create a Google App Password, then put the sending Gmail address in `SMTP_USER` and the App Password in `SMTP_PASS`. Never put your normal Gmail password in the website. After changing `.env`, restart the server.

In the Admin Dashboard, use the email test button to verify delivery.

For production, use HTTPS and a persistent server/volume. Email alerts are intentionally left provider-configurable; add SMTP/provider credentials before enabling outbound email.

## What reaches your Gmail
- New user signup: name, email, and signup time.
- New contact/support inquiry: sender name, sender email (if supplied), message, and time.
- Admin email test: confirms SMTP delivery.

The user's password is never emailed or included in these notifications.
